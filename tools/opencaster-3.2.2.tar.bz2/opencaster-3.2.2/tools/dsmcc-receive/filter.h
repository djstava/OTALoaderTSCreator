


void closePidFiltering (int filter_id);
