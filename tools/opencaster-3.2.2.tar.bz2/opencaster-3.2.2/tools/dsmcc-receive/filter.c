#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <stdio.h>

#include "filter.h"


void closePidFiltering (int filter_id) {

    ;
    
}

